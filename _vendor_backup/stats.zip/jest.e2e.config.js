export default {
	clearMocks: true,
	transform: {},
	testEnvironment: "node",
	coverageProvider: "v8",
	testMatch: ["<rootDir>/tests/e2e/**/*.test.js"],
};
