#!/bin/bash
set -e

cd /workspaces/github-readme-streak-stats
composer install
