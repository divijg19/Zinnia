---
name: Theme Request
about: Request a theme for the project
title: ""
labels: "theme"
assignees: ""
---

**Describe your theme in detail**
A clear description about what the theme would entail.

**Include a screenshot / image**

<!-- Optional -->

**Color palette**
Describe the colors that could be used with this theme.

Are you going to add the theme?

- [ ] Check for yes
