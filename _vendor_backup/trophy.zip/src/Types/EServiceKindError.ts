export enum EServiceKindError {
	RATE_LIMIT = "RATE_LIMITED",
	NOT_FOUND = "NOT_FOUND",
}
